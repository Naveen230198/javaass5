package secondProb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SecondProblem {

	public static void main(String[] args) {
		final String DATA_BASE_DRIVER = "com.mysql.cj.jdbc.Driver";
		
		Statement stmt = null;
		Connection con = null;
		ResultSet rs = null;
		try {
			// load driver
			Class.forName(DATA_BASE_DRIVER);
			System.out.println("driver loaded");
			
			//connect to db
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Emids123");
			System.out.println("Connection established");
			// create statement
			stmt = con.createStatement();
			System.out.println("statement created");
			// execute stmt
			int updated = stmt.executeUpdate("update emp set salary=salary+(salary*0.1)");
			
			
			if(updated!=0) {
				System.out.println("Total records updated : "+updated);
			}

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(con!=null) {
				try {
					con.close();
					System.out.println("Connection closed");
				}catch (Exception e) {
					System.out.println("connection closing exception");
				}
			}
			if(stmt!=null) {
				try {
					stmt.close();
					System.out.println("statement closed");
				}catch (Exception e) {
					System.out.println("statement closing exception");
				}
			}
			if(rs!=null) {
				try {
					rs.close();
					System.out.println("ResultSet closed");
				}catch (Exception e) {
					// TODO: handle exception
					System.out.println("ResultSet closing exception");
				}
			}
		}
		

	}

}
