package fourthProb;

class OuterClass {
	void m1() {
		class InClass {
			void m2() {
				System.out.println("Hi");
			}
		}
		new InClass().m2();
		System.out.println("m1() called");
	}
}

public class FourthProblem {
	public static void main(String[] args) {
		OuterClass obj = new OuterClass();
		obj.m1();
	}
}
